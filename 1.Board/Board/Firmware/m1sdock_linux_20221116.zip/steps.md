1. Make sure the COM port is the bigger one.

2. Burn `low_load_bl808_d0@0x58000000.bin` and `low_load_bl808_m0@0x58000000.bin` as showing in the following picture, it's in MCU label. The end of file name is the image address.
   ![mcu](./.assets/mcu.png)

3. Burn `whole_img_linux@0xD2000.bin` in IOT label,  the end of file name is the image address, this will take a bit long time.
   ![iot](./.assets/iot.png)

4. Then open your serial application, set baudrate 2000000, open the smaller COM port, reset your board by pressing RST key on board, then login as `root`.

```bash
dynamic memory init success,heap size = 26 Kbyte
C906 start...
mtimer clk:1000000
linux load start...
len:0x00376c53
vm linux load done!
dtb load done!
opensbi load done!

load time: 426313 us

OpenSBI v0.6
   ____                    _____ ____ _____
  / __ \                  / ____|  _ \_   _|
 | |  | |_ __   ___ _ __ | (___ | |_) || |
 | |  | | '_ \ / _ \ '_ \ \___ \|  _ < | |
 | |__| | |_) |  __/ | | |____) | |_) || |_
  \____/| .__/ \___|_| |_|_____/|____/_____|
        | |
        |_|

Platform Name          : T-HEAD Xuantie c910
Platform HART Features : RV64ACDFIMSUVX
Platform Max HARTs     : 1
Current Hart           : 0
Firmware Base          : 0x3eff0000
Firmware Size          : 56 KB
Runtime SBI Version    : 0.2
```

```bash

--------Start Local Services--------
********************************
********************************

Linux login: root
login[41]: root login on 'ttyS0'
Processing /etc/profile ...
Set search library path in /etc/profile
Set user path in /etc/profile
id: unknown ID 0
Welcome to Linux
[@Linux root]#
```