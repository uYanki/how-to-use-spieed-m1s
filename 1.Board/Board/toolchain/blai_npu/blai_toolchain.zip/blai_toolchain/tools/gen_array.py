import os,sys,re,argparse,collections

def getArgs():
    parser = argparse.ArgumentParser(description='get inputs')
    parser.add_argument('--input_npu', type=str, nargs=3)
    parser.add_argument('--input_cpu', type=str, nargs=3)
    parser.add_argument('--name', type=str)
    parser.add_argument('--image', type=str)
    parser.add_argument('--image_name', type=str)
    parser.add_argument('--class_name', type=str)
    parser.add_argument('--face', action='store_true')
    parser.add_argument('--output', type=str)
    parser.add_argument('--header', type=str, default='blai_yolo_v4')
    args = parser.parse_args()
    
    return args
    
def main(argv):
    args = getArgs()
    for infile in args.input_npu:
        if not os.path.isfile(infile):
            raise Exception('Incorrect input file {}'.format(infile))
    for infile in args.input_cpu:
        if not os.path.isfile(infile):
            raise Exception('Incorrect input file {}'.format(infile))
    if args.class_name and not os.path.isfile(args.class_name):
        raise Exception('Incorrect input file {}'.format(args.class_name))

    with open(args.output, 'w+') as fout:
        fout.write('#ifndef __{}_H__\n#define __{}_H__\n\n'.format(args.header.upper(), args.header.upper()))
        
        names = []
        feature_list = []
        if args.class_name:
            with open(args.class_name, 'r') as f:
                for l in f.readlines():
                    if len(l.strip()) > 0:
                        names.append(l.strip().replace('\"', ''))
            if args.face:
                name_list = []
                while len(names) > 0:
                    name_list.append(names[0])
                    feature_list.append(names[1:129])
                    names = names[129:]
                fout.write('#define BLAI_POSTPROCESS_TYPE   (2)\n')
                fout.write('#define BLAI_DET_NAME_COUNT    ({})\n'.format(len(name_list)))
                fout.write('#define BALI_DET_FEATURE_NUM    ({})\n'.format(len(feature_list[0])))
                fout.write('static const char* g_detNames[BLAI_DET_NAME_COUNT] = {\n    ')
                for idx, n in enumerate(name_list):
                    if idx > 0 and idx % 8 == 0:
                        fout.write('\n    '.format(n))
                    fout.write('"{}",'.format(n))
                fout.write('\n{};\n\n'.format('}'))
                fout.write('static const float g_feature_list[{}][{}] = {}\n'.format(len(name_list), len(feature_list[0]), '{'))
                for features in feature_list:
                    fout.write('    {\n        ')
                    for idx, n in enumerate(features):
                        if idx > 0 and idx % 16 == 0:
                            fout.write('\n        ')
                        fout.write('{},'.format(n))
                    fout.write('\n    },\n')
                fout.write('{};\n'.format('}'))
            else:            
                fout.write('#define BLAI_POSTPROCESS_TYPE   (1)\n')
                fout.write('#define BLAI_DET_NAME_COUNT    ({})\n'.format(len(names)))
                fout.write('#define BALI_DET_FEATURE_NUM    (0)\n')
                fout.write('static const char* g_detNames[BLAI_DET_NAME_COUNT] = {\n    ')
                for idx, n in enumerate(names[:-1]):
                    if idx > 0 and idx % 8 == 0:
                        fout.write('\n    '.format(n))
                    fout.write('"{}",'.format(n))
                fout.write('    "{}"\n{};\n\n'.format(names[-1], '}'))

                fout.write('static const float **g_feature_list;\n\n')
        else:
            fout.write('#define BLAI_POSTPROCESS_TYPE   (0)\n\n')
        
        fout.write('static const uint8_t {}[] = {}\n'.format(args.name, '{'))
        for idx, infile in enumerate(args.input_cpu):
            fsize = os.path.getsize(infile)
            if idx == 0:
                fout.write('    ')
            fout.write('0x{:02x}, 0x{:02x}, 0x{:02x}, 0x{:02x}, '.format(fsize&0xff, (fsize >> 8 & 0xff), (fsize >> 16 & 0xff), (fsize >> 24 & 0xff)))
        fout.write('0x00, 0x00, 0x00, 0x00,\n')
        for idx, infile in enumerate(args.input_npu):
            fsize = os.path.getsize(infile)
            if idx == 0:
                fout.write('    ')
            fout.write('0x{:02x}, 0x{:02x}, 0x{:02x}, 0x{:02x}, '.format(fsize&0xff, (fsize >> 8 & 0xff), (fsize >> 16 & 0xff), (fsize >> 24 & 0xff)))
        fout.write('0x00, 0x00, 0x00, 0x00,\n')
        data=b''
        for idx, infile in enumerate(args.input_cpu):
            if os.path.getsize(infile) > 0:
                with open(infile, 'rb') as fin:
                    data += fin.read()
        for idx, infile in enumerate(args.input_npu):
            if os.path.getsize(infile) > 0:
                with open(infile, 'rb') as fin:
                    data += fin.read()
        for idx, b in enumerate(data):
            if idx == 0:
                fout.write('    ')
            elif idx % 16 == 0:
                fout.write('\n    '.format(b))
            fout.write('0x{:02x}'.format(b))
            if idx < len(data) - 1:
                fout.write(', '.format(b))
        fout.write('\n{};\n\n'.format('}'));
        
        if args.image:
            with open(args.image, 'rb') as fin:
                    data = fin.read()
                    fout.write('static const uint8_t {}[] = {}\n'.format(args.image_name, '{'))
                    for idx, b in enumerate(data):
                        if idx == 0:
                            fout.write('    ')
                        elif idx % 16 == 0:
                            fout.write('\n    '.format(b))
                        fout.write('0x{:02x}'.format(b))
                        if idx < len(data) - 1:
                            fout.write(', '.format(b))
            fout.write('\n{};\n'.format('}'));
        fout.write('\n')
        
        fout.write('#endif //__{}_H__\n\n'.format(args.header.upper()))

if __name__ == '__main__':
    main(sys.argv)