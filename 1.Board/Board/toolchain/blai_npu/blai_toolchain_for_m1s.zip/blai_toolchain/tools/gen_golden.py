import os,sys,re,argparse,collections

def getArgs():
    parser = argparse.ArgumentParser(description='get inputs')
    parser.add_argument('--input', type=str)
    parser.add_argument('--header', type=str, default='blai_golden')
    args = parser.parse_args()
    
    return args
	
def main(argv):
    args = getArgs()
    if not os.path.isfile(args.input):
        raise Exception('Incorrect input file {}'.format(args.input))


    input_file = args.input
    output_file = input_file.replace('.txt', '.h')
    with open(output_file, 'w+') as fout:
        fout.write('#ifndef __{}_H__\n#define __{}_H__\n\n'.format(args.header.upper(), args.header.upper()))
        if args.input:
            with open(args.input, 'rb') as fin:
                data = fin.readlines()
                fout.write('static const uint8_t {}[] = {}\n'.format('golden', '{'))
                for idx, b in enumerate(data):
                    if idx == 0:
                        fout.write('    ')
                    elif idx % 4 == 0:
                        fout.write('\n    '.format(b))

                    fout.write('0x{:02x}'.format(int(b[6:8], 16)))
                    fout.write(', ')
                    fout.write('0x{:02x}'.format(int(b[4:6], 16)))
                    fout.write(', ')
                    fout.write('0x{:02x}'.format(int(b[2:4], 16)))
                    fout.write(', ')
                    fout.write('0x{:02x}'.format(int(b[0:2], 16)))
                    if idx < len(data) - 1:
                        fout.write(', ')
                fout.write('\n{};\n'.format('}'));
            fout.write('\n')
        fout.write('#endif //__{}_H__\n\n'.format(args.header.upper()))

if __name__ == '__main__':
    main(sys.argv)