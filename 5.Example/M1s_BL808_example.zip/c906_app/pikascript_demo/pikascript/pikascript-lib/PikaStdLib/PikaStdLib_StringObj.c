#include "PikaObj.h"

Arg* PikaStdLib_StringObj___next__(PikaObj* self) {
    return arg_newNull();
}
