from PikaStdLib import MemChecker as mem
import pika_lvgl as lv
import BL808
print('mem used max')
mem.max()
