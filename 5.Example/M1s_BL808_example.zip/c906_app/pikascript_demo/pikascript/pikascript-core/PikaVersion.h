#define PIKA_VERSION_MAJOR       1
#define PIKA_VERSION_MINOR       11
#define PIKA_VERSION_MICRO       5

#define PIKA_EDIT_TIME      "2022/10/24 12:20:33"
