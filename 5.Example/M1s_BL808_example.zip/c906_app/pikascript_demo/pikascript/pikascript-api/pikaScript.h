/* ******************************** */
/* Warning! Don't modify this file! */
/* ******************************** */
#ifndef __pikaScript__H
#define __pikaScript__H
#include <stdio.h>
#include <stdlib.h>
#include "PikaObj.h"
#include "PikaMain.h"

PikaObj * pikaScriptInit(void);

#endif
