#define __platform_printf printf
#define PIKA_OPTIMIZE PIKA_OPTIMIZE_SPEED
#define PIKA_SHELL_SAVE_FILE_ENABLE 1
#define PIKA_SHELL_SAVE_FILE_NAME "/lfs/boot.py"